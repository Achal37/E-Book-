


# Design



![Structural](https://github.com/Arsha28/STEPin-CLanguageEbook/blob/main/2_Architecture/Projectflowchart.png)

