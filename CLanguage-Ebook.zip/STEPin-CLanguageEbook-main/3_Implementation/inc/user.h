#ifndef USER_H_INCLUDED
#define USER_H_INCLUDED


typedef struct userDetails{
  char first[50];
  char last[50];
  char phone[10];
  char email[100];

}user;


#endif // USER_H_INCLUDED
