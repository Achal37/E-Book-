#ifndef TOPICFUNCTIONS_H_INCLUDED
#define TOPICFUNCTIONS_H_INCLUDED
#include<stdio.h>

int functions(int Topicchoice);
int Topicindex();


#endif // TOPICFUNCTIONS_H_INCLUDED
